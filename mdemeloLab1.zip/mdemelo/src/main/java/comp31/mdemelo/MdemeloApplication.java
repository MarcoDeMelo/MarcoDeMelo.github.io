package comp31.mdemelo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MdemeloApplication {

	public static void main(String[] args) {
		SpringApplication.run(MdemeloApplication.class, args);
	}

}
