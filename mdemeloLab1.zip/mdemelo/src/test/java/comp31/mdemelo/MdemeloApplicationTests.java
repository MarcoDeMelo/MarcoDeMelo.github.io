package comp31.mdemelo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MdemeloApplicationTests {

	@Test
	void contextLoads() {
	}

}
